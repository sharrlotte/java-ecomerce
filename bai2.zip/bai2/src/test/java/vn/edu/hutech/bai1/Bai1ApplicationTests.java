package vn.edu.hutech.bai1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bai1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
